package com.empapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmpappJoin01Application {

	public static void main(String[] args) {
		SpringApplication.run(EmpappJoin01Application.class, args);
	}

}
